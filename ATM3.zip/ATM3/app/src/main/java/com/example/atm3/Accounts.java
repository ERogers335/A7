package com.example.atm3;


import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.util.*;
import java.lang.*;

/**
 *
 * This is a class to simulate an ATM. You can enter an ID number which will unlock the deposit/withdraw buttons and show you a generic balance.
 * Use the buttons to withdraw/deposit as you wish.
 *
 * @author Evan R.
 * @version 1.8
 *
 *
 */

public class Accounts {
    private final MainActivity mActivity;
    protected int balance;
    private String ID;
    private String text;
    TextView myTextView;
    TextView accountView;
    TextView num;


    public Accounts (MainActivity activity){
        mActivity = activity;
        balance = 125;
        myTextView =  mActivity.findViewById(R.id.dateTimeBox);
        accountView = mActivity.findViewById(R.id.textView8);
        num = mActivity.findViewById(R.id.editTextNumberPassword);
    }

    /**
     *
     * This method prints the balance, along with time current local date and time.
     *
     */
    public void showStuff(Button reset) {

        InputMethodManager imm = (InputMethodManager) mActivity.getSystemService(MainActivity.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(num.getWindowToken(), 0);

        Button depositB = mActivity.findViewById(R.id.button2);
        Button withdrawB = mActivity.findViewById(R.id.button);

        String currentDateTimeString = java.text.DateFormat.getDateTimeInstance().format(new Date());
        ID = num.getText().toString();

        if(ID.equals("")) {
            Toast.makeText(mActivity, "Please enter your PIN #", Toast.LENGTH_LONG).show();
        } else {
            text = "ID #: " + ID + " Your balance is: " + balance + "$";
            myTextView.setText(currentDateTimeString);
            accountView.setText(text);
            withdrawB.setEnabled(true);
            depositB.setEnabled(true);
            reset.setEnabled(true);
        }
    }

    /**
     *
     * The method to Withdraw an amount and update the balance on screen.
     *
     */
    public void withdraw() {
        int validWithdraw = 20;
        TextView withdraw = mActivity.findViewById(R.id.editTextNumber2);
        int withdrawAmt;
        try {
            withdrawAmt = Integer.parseInt(withdraw.getText().toString());
        } catch (NumberFormatException e) {
            Toast.makeText(mActivity, "Please enter a valid number", Toast.LENGTH_LONG).show();
            return;
        }

        if (withdrawAmt > balance) {
            Toast.makeText(mActivity, "Insufficient funds!", Toast.LENGTH_LONG).show();
            return;
        }
        if (withdrawAmt % validWithdraw != 0) {
            Toast.makeText(mActivity, "Withdrawals must be in multiples of 20.", Toast.LENGTH_LONG).show();
            withdraw.setText("");
            return;
        }

        balance -= withdrawAmt;
        Toast.makeText(mActivity, "Withdrawal Successful!", Toast.LENGTH_SHORT).show();
        text = "ID: " + ID + " Your new balance is: " + balance + "$";
        withdraw.setText("");
        accountView.setText(text);
    }

    /**
     *
     * The method to deposit an amount and update the balance on screen.
     *
     */
    public void deposit() {
        int depositAmt;
        TextView deposit = mActivity.findViewById(R.id.editTextNumber3);

        try {
            depositAmt = Integer.parseInt(deposit.getText().toString());
        } catch (NumberFormatException e) {
            Toast.makeText(mActivity, "Please enter a valid number", Toast.LENGTH_LONG).show();
            return;
        }

        balance += depositAmt;
        Toast.makeText(mActivity, "Deposit Successful!", Toast.LENGTH_SHORT).show();
        text = "ID: " + ID + " Your new balance is: " + balance + "$";
        deposit.setText("");
        accountView.setText(text);
    }
}
