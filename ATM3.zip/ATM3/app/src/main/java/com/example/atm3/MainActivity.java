package com.example.atm3;


import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Accounts accounts = new Accounts(MainActivity.this);
        Button resetButton = findViewById(R.id.button4);
        resetButton.setEnabled(false);

        Button accountButton = findViewById(R.id.button3);
        accountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {accounts.showStuff(resetButton);}
        });

        Button withdrawButton = findViewById(R.id.button);
        withdrawButton.setOnClickListener(new View.OnClickListener() {
            @Override
                    public void onClick(View v) {accounts.withdraw();}
        });
        withdrawButton.setEnabled(false);

        Button depositButton = findViewById(R.id.button2);
        depositButton.setOnClickListener(new View.OnClickListener() {
          @Override
            public void onClick(View v) {accounts.deposit();}
        });
        depositButton.setEnabled(false);


        resetButton.setOnClickListener(new View.OnClickListener() {
          @Override
            public void onClick(View v) {
              accounts.accountView.setText("");
              accounts.balance = 125;
              accounts.num.setText("");
              withdrawButton.setEnabled(false);
              depositButton.setEnabled(false);
              accounts.myTextView.setText("");
              Toast.makeText(MainActivity.this, "Thanks for using the ATM. Have a nice day! :)", Toast.LENGTH_LONG).show();
              resetButton.setEnabled(false);
          }
        });
    }
}